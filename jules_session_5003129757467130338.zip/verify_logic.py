from playwright.sync_api import sync_playwright

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto("http://localhost:8000")

        # Wait for the main tabs container to be visible (class .main-tabs)
        page.wait_for_selector(".main-tabs")

        # Wait for the switchMainTab function to exist on window
        page.wait_for_function("typeof window.switchMainTab !== 'undefined'")

        # Open Special Situations
        page.evaluate("window.switchMainTab('special')")
        
        # Wait for special sit tools to be accessible
        page.wait_for_function("typeof window.switchSpecialSitTab !== 'undefined'")
        
        # Open Buyback Subtab
        page.evaluate("window.switchSpecialSitTab('buyback')")

        # Fill inputs
        page.fill("#bb-symbol", "RELIANCE")
        
        # Sync Prices
        page.click("button:has-text('Sync from Back End')")
        page.wait_for_timeout(2000)

        # Sync Holdings
        page.click("button:has-text('Sync'):left-of(:has-text('Unverified'))")
        page.wait_for_timeout(2000)
        
        # Test Promoter participates calculation
        page.check("#bb-promoter-participates")
        page.evaluate("window.calculateBuyback()")
        post_promoter_pct = page.inner_text("#bb-promoter-post-pct")
        print(f"Post Promoter % (Participates): {post_promoter_pct}")
        
        # Test Promoter does NOT participate
        page.uncheck("#bb-promoter-participates")
        page.evaluate("window.calculateBuyback()")
        post_promoter_pct_no_part = page.inner_text("#bb-promoter-post-pct")
        print(f"Post Promoter % (Does Not Participate): {post_promoter_pct_no_part}")

        # Check future logic
        print("Fut 1 price:", page.input_value("#bb-fut-price"))

        page.select_option("#bb-future-sel", "2")
        page.wait_for_timeout(500)
        print("Fut 2 price:", page.input_value("#bb-fut-price"))

        page.select_option("#bb-future-sel", "3")
        page.wait_for_timeout(500)
        print("Fut 3 price:", page.input_value("#bb-fut-price"))
        
        page.screenshot(path="/home/jules/verification/screenshots/verification3.png")
        
        browser.close()

if __name__ == "__main__":
    main()
