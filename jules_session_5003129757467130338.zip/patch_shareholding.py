import requests
import pandas as pd
import json

def patch_shareholding(symbol):
    try:
        url = f"http://127.0.0.1:8000/api/data/shareholding?symbol={symbol}"
        response = requests.get(url)
        if response.status_code == 200:
            print(f"Successfully fetched shareholding data for {symbol}")
            print(response.json())
        else:
            print(f"Failed to fetch data for {symbol}. Status code: {response.status_code}")
    except Exception as e:
        print(f"Error fetching data for {symbol}: {e}")

if __name__ == "__main__":
    patch_shareholding("AAPL")
